import random
import difflib

def processar_comando(entrada):
            """Processa o comando do usuário e executa a ação correta"""
            partes = entrada.split(" ")  # Separa o comando principal do restante
            comando = partes[0].lower()
            if comando == '/proverbio':
                proverbios = [
                "A pressa é inimiga da perfeição.",
                "Quem semeia ventos, colhe tempestades.",
                "Água mole em pedra dura, tanto bate até que fura.",
                "Mais vale um pássaro na mão do que dois voando.",
                "De grão em grão, a galinha enche o papo.",
                "Antes tarde do que nunca.",
                "Quem ri por último, ri melhor.",
                "Nem tudo que reluz é ouro.",
                "A união faz a força.",
                ]
                return random.choice(proverbios)
            elif comando == '/calcular':
                try:
                    num1 = float(partes[1])
                    num2 = float(partes[3])
                    sinal = partes[2]
                    if sinal == '*':
                        resultado = num1*num2
                        return resultado
                    elif sinal == '+':
                        resultado = num1+num2
                        return resultado
                    elif sinal == '-':
                        resultado = num1-num2
                        return resultado
                    elif sinal == '/':
                        resultado = num1/num2
                        return resultado
                    elif sinal == '**':
                         resultado == num1**num2
                         return resultado
                    elif sinal == '%':
                        resultado == num1%num2
                        return resultado
                    else:
                        return 'erro de operador'
                except ValueError:
                    return 'Você digitou um numero errado!'

def sin(palavra):
        sinonimos = {
            'Obrigado': ['Eu agradeço', 'Gratidão', 'Valeu', 'Só força', 'Obrigado'],
            'Voce': ['Tu', 'Você'],
            'voce': ['tu', 'você'],
            'eu': ['eu', 'eu mesmo'],
            'Eu': ['Eu', 'Eu mesmo'],
            'marreta': ['martelo', 'marretão', 'marreta', 'aquele negocio de martelar'],
            'dinheiro': ['bonus', 'credito positivo', 'dinheiro'],
            'Oi': ['Olá, ', 'Saudações, ', 'Oi, ', 'Opa, ', 'Ei, '],
            'feliz': ['contente', 'alegre', 'radiante', 'satisfeito', 'feliz'],
            'triste': ['chateado', 'desanimado', 'melancólico', 'deprimido', 'triste'],
            'rápido': ['veloz', 'ligeiro', 'ágil', 'rapido'],
            'devagar': ['lento', 'calmo', 'tranquilo', 'pausado', 'devagar'],
            'grande': ['enorme', 'gigante', 'vasto', 'amplo', 'grande'],
            'pequeno': ['mínimo', 'reduzido', 'compacto', 'miúdo', 'pequeno'],
            'amor': ['afeto', 'carinho', 'amor'],
            'ódio': ['raiva', 'rancor', 'desgosto', 'ódio'],
            'felicidade': ['alegria', 'contentamento', 'satisfação', 'felicidade'],
            'tristeza': ['melancolia', 'desânimo', 'sofrimento', 'tristeza'],
            'inteligente': ['esperto', 'sábio', 'genial', 'inteligente'],
            'bonito': ['belo', 'atraente', 'charmoso', 'bonito'],
            'carro': ['automóvel', 'veículo', 'máquina', 'carro'],
            'casa': ['lar', 'residência', 'moradia', 'casa'],
            'comida': ['alimento', 'refeição', 'prato', 'comida'],
            'trabalho': ['emprego', 'ocupação', 'profissão', 'trabalho'],
            'escola': ['colégio', 'instituição de ensino', 'educação', 'escola'],
            'amigo': ['companheiro', 'parceiro', 'camarada', 'amigo'],
            'felicidade': ['alegria', 'contentamento', 'satisfação', 'felicidade'],
            'tristeza': ['melancolia', 'desânimo', 'sofrimento', 'tristeza'],
            'rápido': ['veloz', 'ligeiro', 'ágil', 'rápido'],
            'devagar': ['lento', 'calmo', 'tranquilo', 'devagar'],
            'grande': ['enorme', 'gigante', 'vasto', 'grande'],
            'pequeno': ['mínimo', 'reduzido', 'compacto', 'pequeno'],
            'inteligente': ['esperto', 'sábio', 'genial', 'inteligente'],
            'bonito': ['belo', 'atraente', 'charmoso', 'bonito'],
            'feliz': ['contente', 'alegre', 'radiante', 'satisfeito', 'feliz'],
            'triste': ['chateado', 'desanimado', 'melancólico', 'deprimido', 'triste'],
            'ajudar': ['auxiliar', 'ajudar', 'colaborar'],
            'precisa': ['tanto almejas', 'necessitas', 'precisa']
        }
        return random.choice(sinonimos.get(palavra, [palavra]))
    
def frases_comuns(codigo):
    frases = {
            'r1': [f'que dia {sin('bonito')}, não acha?', f'meu {sin('amigo')}, gostaria de ouvir um proverbio? É só digitar /proverbio.', f'bom dia {sin('amigo')}', 'tudo bem?', 'que que ta pegando?', f'hoje é um ótimo dia para ser {sin("feliz")}.', f'você sabia que {sin("trabalho")} dignifica o homem?', f'que tal uma boa {sin("comida")} hoje?', f'espero que você esteja se sentindo {sin("inteligente")} hoje.', f'não se esqueça de valorizar o {sin("amor")} em sua vida.'],
            'r2': [f'Estou aqui para {sin('ajudar')}!', f'O que {sin('voce')} {sin('precisa')} pra hoje?']
      }
    return random.choice(frases.get(codigo, [codigo]))
def responder(mensagem):
    database = {
          'oi': [f'{sin('Oi')}{frases_comuns('r1')}'],
          'Oi': [f'{sin('Oi')}{frases_comuns('r1')}'],
          'ola': [f'{sin('Oi')}{frases_comuns('r1')}'],
          'Ola': [f'{sin('Oi')}{frases_comuns('r1')}'],
          'como você está?': [f'Estou apenas um programa, mas {sin('Obrigado')} por perguntar! {frases_comuns('r2')}', f'Estou funcionando perfeitamente, e {sin('voce')}?'],
          'qual é o seu nome?': [f'Eu sou o Krepus, seu assistente virtual. {frases_comuns('r2')}', f'Pode me chamar de Krepus! {frases_comuns('r2')}'],
          'o que você pode fazer?': ['Posso calcular, contar provérbios, e até responder perguntas simples!', 'Sou capaz de realizar várias tarefas, como cálculos e prover frases motivacionais.'],
          'qual é o sentido da vida?': ['42, segundo o Guia do Mochileiro das Galáxias!', 'O sentido da vida é o que você faz dela.'],
          'quem é você?': ['Sou um assistente virtual criado para ajudar você.', 'Sou o Krepus, um programa aqui para facilitar sua vida.'],
    }
    result = difflib.get_close_matches(mensagem, database.keys(), n=1, cutoff=0.6)
    if result:
        return random.choice(database.get(result[0], [mensagem]))
    else:
        return processar_comando(entrada)


#interface(hahaha it is terminal)
print('krepus')
while True:
     entrada = input('---> ')
     resposta = responder(entrada)
     print(resposta)